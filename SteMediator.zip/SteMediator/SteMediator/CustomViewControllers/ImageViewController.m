//
//  ImageViewController.m
//  SteMediator
//
//  Created by Apple on 2017/8/11.
//  Copyright © 2017年 com.taobus.www. All rights reserved.
//

#import "ImageViewController.h"

@interface ImageViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (weak, nonatomic) IBOutlet UILabel *messageLabel;
@end

@implementation ImageViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    self.imageView.image = [UIImage imageNamed:self.imageName];
    self.messageLabel.text = self.message;
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)dismissAction:(id)sender {
    
    if (self.navigationController) {
        [self.navigationController popViewControllerAnimated:YES];
    }else if (self.presentingViewController){
        [self.presentingViewController dismissViewControllerAnimated:YES completion:nil];
    }

}


/*
#pragma mark - Navigation
// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
