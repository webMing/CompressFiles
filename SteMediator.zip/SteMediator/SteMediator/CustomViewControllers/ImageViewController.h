//
//  ImageViewController.h
//  SteMediator
//
//  Created by Apple on 2017/8/11.
//  Copyright © 2017年 com.taobus.www. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ImageViewController : UIViewController

/** imageView */
@property (copy, nonatomic) NSString *imageName;
/** message */
@property (copy, nonatomic) NSString* message;

@end
