//
//  SteMediator.h
//  SteMediator
//
//  Created by Apple on 2017/8/11.
//  Copyright © 2017年 com.taobus.www. All rights reserved.
//


#import <Foundation/Foundation.h>

@interface SteMediator : NSObject

+(instancetype)shareMediator;

- (id)performTarget:(NSString*)targetName
               action:(NSString*)actionName
                 para:(NSDictionary*)dict
          shouldCache:(BOOL)cache;

@end
