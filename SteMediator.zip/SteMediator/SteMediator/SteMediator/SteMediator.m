//
//  SteMediator.m
//  SteMediator
//
//  Created by Apple on 2017/8/11.
//  Copyright © 2017年 com.taobus.www. All rights reserved.
//

#import "SteMediator.h"

@interface SteMediator ()
/** cacheObj */
@property (strong, nonatomic) NSMutableDictionary *cacheObjMutDict;

@end

@implementation SteMediator

+(instancetype)shareMediator {
    static dispatch_once_t onceToken;
    static SteMediator* mediator;
    dispatch_once(&onceToken, ^{
        mediator = [self new];
    });
    return mediator;
}

- (id)performTarget:(NSString* )targetName
               action:(NSString* )actionName
                 para:(NSDictionary*)dict
          shouldCache:(BOOL)cache {
    
    NSString* TargetClassString = [NSString stringWithFormat:@"Target_%@",targetName];
    
    NSString* actionString;
    
    if (dict) {
       actionString = [NSString stringWithFormat:@"Action_%@:",actionName];
    }else{
       actionString = [NSString stringWithFormat:@"Action_%@",actionName];
    }
    
    id target = [self.cacheObjMutDict objectForKey:targetName];
    
    if (!target) {
        Class className = NSClassFromString(TargetClassString);
        target = [[className alloc]init];
    }
    
    SEL sel = NSSelectorFromString(actionString);
    
    if (target && sel) {
        if ([target respondsToSelector:sel]) {
            if (cache) {
                [self.cacheObjMutDict setValue:target forKey:targetName];
            }
           return [target performSelector:sel withObject:dict];
        }else{
            NSLog(@"Target:%@ unable responds to selector:%@",target, NSStringFromSelector(sel));
        }
    }else {
        NSLog(@"Target:%@  Selector:%@",target, NSStringFromSelector(sel));
    }
    
    return nil;
    
}

- (NSMutableDictionary*)cacheObjMutDict {
    
    if (!_cacheObjMutDict) {
        _cacheObjMutDict = NSMutableDictionary.new;
    }
    return _cacheObjMutDict;
}

- (void)clearTarget {
    //对象清空.
    
}
@end
