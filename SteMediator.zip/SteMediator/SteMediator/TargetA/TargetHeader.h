//
//  TargetAHeader.h
//  SteMediator
//
//  Created by Apple on 2017/8/11.
//  Copyright © 2017年 com.taobus.www. All rights reserved.
//

#import <Foundation/Foundation.h>

#ifndef TargetAHeader_h
#define TargetAHeader_h

FOUNDATION_EXPORT NSString const * TargetAString ;
FOUNDATION_EXPORT NSString const * PresentControllerMethodString ;
FOUNDATION_EXPORT NSString const * AViewControllerMethodString;
FOUNDATION_EXPORT NSString const * PushViewControllerWithImageMethodString ;
FOUNDATION_EXPORT NSString const * ShowAlterViewMethodString ;

#endif /* TargetAHeader_h */
