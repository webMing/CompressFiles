//
//  TargetA.h
//  SteMediator
//
//  Created by Apple on 2017/8/11.
//  Copyright © 2017年 com.taobus.www. All rights reserved.
//
#import <Foundation/Foundation.h>
@interface Target_A : NSObject
@end
