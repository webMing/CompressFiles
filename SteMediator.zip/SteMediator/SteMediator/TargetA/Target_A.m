//
//  TargetA.m
//  SteMediator
//
//  Created by Apple on 2017/8/11.
//  Copyright © 2017年 com.taobus.www. All rights reserved.
//

#import "Target_A.h"
#import <UIKit/UIKit.h>
#import "TargetHeader.h"
#import "ImageViewController.h"

//全局变量拿出来.
NSString   *TargetAString = @"A";
NSString  const * PresentControllerMethodString = @"presentAViewController";
NSString  * AViewControllerMethodString = @"AViewController";
NSString  * PushViewControllerWithImageMethodString = @"pushAViewControllerWithPara";
NSString  * ShowAlterViewMethodString = @"showAlterViewWithPara";

static inline id SteLoadFromSbWithIdentify(NSString* identify){
    UIStoryboard* sb = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    return [sb instantiateViewControllerWithIdentifier:identify];
}

@implementation Target_A

- (UIViewController*)Action_AViewController{
    return SteLoadFromSbWithIdentify(@"AViewController");
}

- (void)Action_presentAViewController {
    UIViewController* presentViewController = SteLoadFromSbWithIdentify(@"AViewController");
    [[UIApplication sharedApplication].keyWindow.rootViewController presentViewController:presentViewController animated:YES completion:nil];
    
}

- (UIViewController*)Action_pushAViewControllerWithPara:(NSDictionary*)dict{
    
    ImageViewController* imageVC = SteLoadFromSbWithIdentify(@"ImageViewController");
    imageVC.message = [dict objectForKey:@"message"];
    imageVC.imageName = [dict objectForKey:@"image"];
    return imageVC;
    
}

- (void)Action_showAlterViewWithPara:(NSDictionary*)dict{
    
    void(^confirm)(void) = (id)[dict objectForKey:@"confirm"];
    void(^cancle)(void) = (id)[dict objectForKey:@"cancle"];
    UIAlertAction* confirmAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        confirm();
    }];
    UIAlertAction* cancleAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        cancle();
    }];
    UIAlertController* alterController = [UIAlertController alertControllerWithTitle:@"是否取消" message:nil
                                                                      preferredStyle:UIAlertControllerStyleAlert];
    [alterController addAction:confirmAction];
    [alterController addAction:cancleAction];
    [[UIApplication sharedApplication].keyWindow.rootViewController presentViewController:alterController animated:YES completion:nil];
    
}

@end
