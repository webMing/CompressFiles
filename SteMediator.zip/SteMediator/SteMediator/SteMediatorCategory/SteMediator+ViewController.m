//
//  SteMediator+ViewController.m
//  SteMediator
//
//  Created by Apple on 2017/8/11.
//  Copyright © 2017年 com.taobus.www. All rights reserved.
//

#import "SteMediator+ViewController.h"
#import "TargetHeader.h"

@implementation SteMediator (ViewController)

- (UIViewController*)aViewController {
   //有返回值.
   NSString* target = [NSString stringWithFormat:@"%@",TargetAString];
   NSString* action = [NSString stringWithFormat:@"%@",AViewControllerMethodString];
   return [self performTarget:target action:action para:nil shouldCache:NO];
    
}

- (void)presentAViewController {
    
    //没有返回值;直接执行逻辑.
    [self performTarget:TargetAString action:PresentControllerMethodString para:nil shouldCache:NO];
    
}

//参数在这里组装.
- (UIViewController*)pushAViewControllerWithImageName:(NSString*)imageName {
    
    NSString* target = [NSString stringWithFormat:@"%@",TargetAString];
    NSString* action = [NSString stringWithFormat:@"%@",PushViewControllerWithImageMethodString];
    if (!imageName) {
        imageName = @"noImage";
    }
    return [self performTarget:target action:action para: @{@"image":imageName,@"message":@"你好"} shouldCache:NO];

}

- (void)showAlterViewWithConfirmAction:(void(^)(void))confirm cancleBlock:(void(^)(void))cancle {
    
    NSString* target = [NSString stringWithFormat:@"%@",TargetAString];
    NSString* action = [NSString stringWithFormat:@"%@",ShowAlterViewMethodString];
    [self performTarget:target action:action para: @{@"confirm":confirm,@"cancle":cancle} shouldCache:NO];
    
}

@end
