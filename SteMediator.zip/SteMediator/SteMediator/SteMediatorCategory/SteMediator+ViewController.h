//
//  SteMediator+ViewController.h
//  SteMediator
//
//  Created by Apple on 2017/8/11.
//  Copyright © 2017年 com.taobus.www. All rights reserved.
//

#import "SteMediator.h"
#import <UIKit/UIKit.h>

@interface SteMediator (ViewController)

- (UIViewController*)aViewController;
- (void)presentAViewController;
- (UIViewController*)pushAViewControllerWithImageName:(NSString*)imageName;
- (void)showAlterViewWithConfirmAction:(void(^)(void))confirm cancleBlock:(void(^)(void))cancle;

@end
