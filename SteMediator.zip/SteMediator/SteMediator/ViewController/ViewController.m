//
//  ViewController.m
//  SteMediator
//
//  Created by Apple on 2017/8/11.
//  Copyright © 2017年 com.taobus.www. All rights reserved.
//

#import "ViewController.h"
#import "SteMediator+ViewController.h"

@interface ViewController ()<UITableViewDelegate,UITableViewDataSource>
/** tableViewDataSource */
@property (strong, nonatomic) NSArray *tableViewDateSource;

@end

@implementation ViewController

#pragma mark- LifeCicle

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark- CreateUI

#pragma mark- EventRespone

#pragma mark- CustomDelegateMethod

#pragma mark- DelegateMethod

#pragma mark- UItableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.tableViewDateSource.count;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    return [tableView dequeueReusableCellWithIdentifier:@"CELL"];
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath{
    cell.textLabel.text = self.tableViewDateSource[indexPath.row];
}


#pragma mark- UItableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
    
    switch (indexPath.row ) {
        case 0:
        {
            UIViewController* viewController =  [[SteMediator shareMediator]aViewController];
            [self.navigationController pushViewController:viewController animated:YES];
            break;
        }
        case 1:
        {   [[SteMediator shareMediator]presentAViewController];
            break;
        }
        case 2:
        {
           UIViewController* contr =  [[SteMediator shareMediator]pushAViewControllerWithImageName:@"image"];
           [self.navigationController pushViewController:contr animated:YES];
           break;
        }
        case 3:
        {   UIViewController* contr =  [[SteMediator shareMediator]pushAViewControllerWithImageName:nil];
            [self.navigationController pushViewController:contr animated:YES];
            break;
        }
        case 4:
        {
            [[SteMediator shareMediator]showAlterViewWithConfirmAction:^{
                NSLog(@"确定执行啦");
            } cancleBlock:^{
                NSLog(@"取消啦");
            }];
            break;
        }
        default:
            // do nothing.
            break;
    }
}

#pragma mark- DetterAndSetter

- (NSArray*)tableViewDateSource{
    
    if (!_tableViewDateSource) {
        
        _tableViewDateSource = @[
                                 @"pushAViewController",
                                 @"presentViewController",
                                 @"presentAImageViewController",
                                 @"presentImageWithError",
                                 @"showAlterView",
                                 ];
    }
    return _tableViewDateSource;
}

#pragma mark- PrivateMethod





@end
