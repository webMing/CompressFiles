//
//  CommonHeader.h
//  CTNetworking
//
//  Created by casa on 15/12/31.
//  Copyright © 2015年 casa. All rights reserved.
//

#ifndef CommonHeader_h
#define CommonHeader_h

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSUInteger, TestCaseType) {
    TestCaseTypeFireSingleAPI,
    
};

#endif /* CommonHeader_h */
