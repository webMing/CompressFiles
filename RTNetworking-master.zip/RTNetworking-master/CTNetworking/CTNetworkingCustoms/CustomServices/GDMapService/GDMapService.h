//
//  GDMapService.h
//  CTNetworking
//
//  Created by casa on 16/4/12.
//  Copyright © 2016年 casa. All rights reserved.
//

#import "CTService.h"

@interface GDMapService : CTService <CTServiceProtocol>

@end
