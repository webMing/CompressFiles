//
//  AppDelegate.h
//  CTNetworking
//
//  Created by LongFan on 16/5/26.
//  Copyright © 2016年 Long Fan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

