//
//  NSMutableString+AXNetworkingMethods.h
//  RTNetworking
//
//  Created by casa on 14-5-17.
//  Copyright (c) 2014年 casatwy. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSMutableString (AXNetworkingMethods)

- (void)appendURLRequest:(NSURLRequest *)request;

@end
