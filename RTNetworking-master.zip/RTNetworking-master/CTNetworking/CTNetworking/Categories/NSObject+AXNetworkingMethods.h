//
//  NSObject+AXNetworkingMethods.h
//  RTNetworking
//
//  Created by casa on 14-5-6.
//  Copyright (c) 2014年 casatwy. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObject (AXNetworkingMethods)

- (id)CT_defaultValue:(id)defaultData;
- (BOOL)CT_isEmptyObject;

@end
