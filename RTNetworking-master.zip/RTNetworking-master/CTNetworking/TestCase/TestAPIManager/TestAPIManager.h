//
//  TestAPIManager.h
//  CTNetworking
//
//  Created by casa on 15/12/31.
//  Copyright © 2015年 casa. All rights reserved.
//

#import "CTNetworking.h"

extern NSString * const kTestAPIManagerParamsKeyLatitude;
extern NSString * const kTestAPIManagerParamsKeyLongitude;

@interface TestAPIManager : CTAPIBaseManager <CTAPIManager>

@end
