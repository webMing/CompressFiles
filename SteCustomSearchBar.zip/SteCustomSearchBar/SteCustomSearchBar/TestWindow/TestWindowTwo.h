//
//  TestWindowTwo.h
//  SteCustomSearchBar
//
//  Created by Apple on 17/3/24.
//  Copyright © 2017年 com.taobus.www. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TestWindowTwo : UIWindow

@end
