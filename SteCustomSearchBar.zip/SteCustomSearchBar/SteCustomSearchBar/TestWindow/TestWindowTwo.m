//
//  TestWindowTwo.m
//  SteCustomSearchBar
//
//  Created by Apple on 17/3/24.
//  Copyright © 2017年 com.taobus.www. All rights reserved.
//

#import "TestWindowTwo.h"

@implementation TestWindowTwo

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/


-(instancetype)init{
    
    if (self = [super init]) {
        
        self.backgroundColor = [UIColor greenColor];
    }
    return self;
}

-(instancetype)initWithFrame:(CGRect)frame{
    
    if (self = [super initWithFrame:frame]) {
        
        self.backgroundColor = [UIColor greenColor];

    }
    
    return self;
}


-(NSString*)description{
    
    return [NSString stringWithFormat:@"ClassName: %@ adrress:%p",self.class,self];
}

/**
 *  通知
 **/
-(void)becomeKeyWindow{
    
    NSLog(@"%@ %@",self,NSStringFromSelector(_cmd));

}

-(void)resignKeyWindow{
    
    NSLog(@"%@ %@",self,NSStringFromSelector(_cmd));

}
@end
