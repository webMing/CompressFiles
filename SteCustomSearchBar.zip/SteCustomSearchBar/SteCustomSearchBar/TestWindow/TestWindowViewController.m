//
//  TestWindowViewController.m
//  SteCustomSearchBar
//
//  Created by Apple on 17/3/24.
//  Copyright © 2017年 com.taobus.www. All rights reserved.
//

#import "TestWindowViewController.h"

#import "TestWindowOne.h"

#import "TestWindowTwo.h"


@interface TestWindowViewController ()<UIActionSheetDelegate>

@end

@implementation TestWindowViewController


-(void)viewDidAppear:(BOOL)animated{
    
    [super viewDidAppear:animated];
    
    NSLog(@"%@",self.view.window);
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
   
    // Do any additional setup after loading the view.
}


- (void)didReceiveMemoryWarning {
    
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}




/**
 *  checkKeyWindow
 **/

- (IBAction)checkKeyWindow :(id)sender{
    
    NSLog(@"%@", [UIApplication sharedApplication].keyWindow);
    
}


/**
 *  alterView
 **/
- (IBAction)showAlterView :(id)sender{
    
    
//    UIAlertView* alterView = [[UIAlertView alloc]initWithTitle:@"AlterView" message:nil delegate:nil cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
//    [alterView show];
//    
//    NSLog(@"%@",alterView.window);
    
    TestWindowOne* window = [[TestWindowOne alloc]initWithFrame:CGRectMake(0,0,self.view.frame.size.width, 40)];
    //window.windowLevel = UIWindowLevelAlert;

    [window makeKeyAndVisible];

    [self.view addSubview:window];
    
    
}


/**
 *  actionSheet
 **/
- (IBAction)showDiffLevelWindow:(id)sender {
    
//    UIActionSheet* sheet = [[UIActionSheet alloc]initWithTitle:@"ActionSheet" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"确定", nil];
//    
//    [sheet showInView:self.view];
//    
//    NSLog(@"%@",sheet.window);

}



-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    
   
}
@end
