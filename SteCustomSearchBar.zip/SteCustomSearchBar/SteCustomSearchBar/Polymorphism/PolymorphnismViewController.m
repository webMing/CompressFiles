//
//  PolymorphnismViewController.m
//  SteCustomSearchBar
//
//  Created by Apple on 17/3/28.
//  Copyright © 2017年 com.taobus.www. All rights reserved.
//

#import "PolymorphnismViewController.h"


#import "TestB.h"

@interface PolymorphnismViewController ()

@end

@implementation PolymorphnismViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    //[self performSelector:<#(nonnull SEL)#> withObject:<#(nullable id)#> afterDelay:<#(NSTimeInterval)#>];
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


/// 调用方法A

- (IBAction)callAmethod:(UIButton *)sender {
    
    TestB* b = [TestB new];
    
    [b aMethod];
    
    [b performSelector:@selector(customMethod)];
    
}


/// 调用方法B

- (IBAction)callBmethod:(UIButton *)sender {
 
    TestB* b = [TestB new];
    
    [b bMethod];
    
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
