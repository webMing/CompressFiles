//
//  TestA.m
//  SteCustomSearchBar
//
//  Created by Apple on 17/3/24.
//  Copyright © 2017年 com.taobus.www. All rights reserved.
//

#import "TestA.h"

@implementation TestA

-(instancetype)init{
    
    if (self = [super init]) {
        
    }
    
    return self;
}


/// 父类的方法子类必须重写-->>>如果子类重写父类方法,必须先调用父类方法,再调用子类方法.
-(void)aMethod{
    
    //先调用父类方法,
    {
        NSLog(@"父类方法:AMethod");
    }
    
    //再调用子类方法.
    if ([self.vituralChild respondsToSelector:@selector(overrideAMethod)]) {
        
        [self.vituralChild overrideAMethod];
    }
    
}

/// 父类的方法子类可选重写-->>>如果子类重写父类方法,调用子类的方法，如果没有重写调用父类方法.

-(void)bMethod{
    
    if ([self.vituralChild respondsToSelector:@selector(overriveBMethod)]) {
        
        [self.vituralChild overriveBMethod];
        
    }else{
        
        NSLog(@"父类方法:BMethod");
        
    }
    
}
@end
