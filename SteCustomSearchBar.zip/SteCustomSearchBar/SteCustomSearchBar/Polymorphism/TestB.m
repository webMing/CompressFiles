//
//  TestB.m
//  SteCustomSearchBar
//
//  Created by Apple on 17/3/24.
//  Copyright © 2017年 com.taobus.www. All rights reserved.
//

#import "TestB.h"

@implementation TestB

-(instancetype)init{
    
    if (self = [super init]) {
        
        /// 这里警告为什么没有
        self.vituralChild =  (id)self;
    }
    
    return self;
    
}


///如果重写此方法以子类方法为准.
-(void)overrideAMethod{
    
    NSLog(@"子类方法,调用 AMethod");
}


///如果重写此方法以子类方法为准.
-(void)overriveBMethod{
    
    NSLog(@"子类方法,调用 BMethod");
    
}
@end
