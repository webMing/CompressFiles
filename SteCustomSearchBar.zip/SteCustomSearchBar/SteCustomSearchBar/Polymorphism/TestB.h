//
//  TestB.h
//  SteCustomSearchBar
//
//  Created by Apple on 17/3/24.
//  Copyright © 2017年 com.taobus.www. All rights reserved.
//

#import "TestA.h"

@interface TestB : TestA<TestAProtocol>

@end
