//
//  TestA.h
//  SteCustomSearchBar
//
//  Created by Apple on 17/3/24.
//  Copyright © 2017年 com.taobus.www. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>


@protocol TestAProtocol <NSObject>

/// 必须重写的方法
@required
-(void)overrideAMethod;

/// 可选重写的方法
@optional
-(void)overriveBMethod;


@end


@interface TestA : NSObject

@property(weak, nonatomic) id<TestAProtocol> vituralChild;

-(void)aMethod;

-(void)bMethod;

@end
