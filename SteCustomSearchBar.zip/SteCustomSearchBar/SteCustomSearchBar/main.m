//
//  main.m
//  SteCustomSearchBar
//
//  Created by Apple on 17/3/23.
//  Copyright © 2017年 com.taobus.www. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
