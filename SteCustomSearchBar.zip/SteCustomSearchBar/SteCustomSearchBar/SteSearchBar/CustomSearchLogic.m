//
//  CustomSearchLogic.m
//  SteCustomSearchBar
//
//  Created by Apple on 17/3/23.
//  Copyright © 2017年 com.taobus.www. All rights reserved.
//

#import "CustomSearchLogic.h"

@implementation CustomSearchLogic

-(void)search{
    
    NSLog(@"gogog");
}
@end
