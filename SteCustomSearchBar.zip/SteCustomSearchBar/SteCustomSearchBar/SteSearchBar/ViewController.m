//
//  ViewController.m
//  SteCustomSearchBar
//
//  Created by Apple on 17/3/23.
//  Copyright © 2017年 com.taobus.www. All rights reserved.
//

#import "ViewController.h"

#import "SteCustomSearchBar.h"

#import "CustomSearchViewTypeOne.h"

#import "CustomSearchLogic.h"


@interface ViewController ()

@end



@implementation ViewController


-(void)viewDidAppear:(BOOL)animated{
    
    [super viewDidAppear:animated];
    
}


- (void)viewDidLoad {
    
   [super viewDidLoad];

   SteCustomSearchBar* searchBar = [[SteCustomSearchBar
                                      alloc]initWithFrame:CGRectMake(0,20,CGRectGetWidth(self.view.frame), 40)];


   searchBar.searchView = [CustomSearchViewTypeOne loadFromNib];
    
   searchBar.searchLogic = [CustomSearchLogic new];
    
   [self.view addSubview:searchBar];

   //UITextField* searchTextFiled = [];
    // Do any additional setup after loading the view, typically from a nib.
   //NSLog(@"system version:%@", [UIDevice currentDevice].systemVersion);
    
   //NSString* systemVersionComponentArray =  [[UIDevice currentDevice].systemVersion componentsSeparatedByString:@"."];
   
    
}

- (void)didReceiveMemoryWarning {
    
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}






@end
