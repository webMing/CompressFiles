//
//  SteCustomSearchBar.m
//  SteCustomSearchBar
//
//  Created by Apple on 17/3/23.
//  Copyright © 2017年 com.taobus.www. All rights reserved.
//

#import "SteCustomSearchBar.h"
#import "SteSearchView.h"

@implementation SteCustomSearchBar

-(instancetype)init{
    
    if (self = [super init]) {
        
    }
    return self;
    
}


-(void)setSearchView:(SteSearchView *)searchView{
    
    [_searchView removeFromSuperview];
    _searchView = searchView;
    [self addSubview: _searchView];
    
    if (_searchLogic) {
        _searchView.delegate = (id) _searchLogic;
    }
    
}


-(void)setSearchLogic:(NSObject<SteCustomSearchBarProtocal> *)searchLogic{
    
    _searchLogic = searchLogic;
    
    if (_searchView) {
        
        _searchView.delegate = (id) _searchLogic;
        
    }
}


-(void)layoutSubviews{

    [super layoutSubviews];
    
   _searchView.frame = CGRectMake(0, 0, CGRectGetWidth(self.frame), CGRectGetHeight(self.frame));
    
}

@end
