//
//  CustomSearchViewTypeOne.m
//  SteCustomSearchBar
//
//  Created by Apple on 17/3/23.
//  Copyright © 2017年 com.taobus.www. All rights reserved.
//


#define IS_IOS_5  (([[[[UIDevice currentDevice].systemVersion componentsSeparatedByString:@"."] objectAtIndex:0] intValue] >= 5) ? YES : NO)


#define IS_IOS_9  (([[[[UIDevice currentDevice].systemVersion componentsSeparatedByString:@"."] objectAtIndex:0] intValue] >= 9) ? YES : NO)


#import "CustomSearchViewTypeOne.h"


@interface CustomSearchViewTypeOne ()<UISearchBarDelegate>

@property (weak, nonatomic) IBOutlet UISearchBar *searchBar;

@end


@implementation CustomSearchViewTypeOne


-(void)awakeFromNib{
    
  [super awakeFromNib];
    
   if (IS_IOS_5 ) {
        
        UIBarButtonItem* cancleBarButtomItem ;
        
        if (IS_IOS_9) {
            
            // >= iOS.9
            cancleBarButtomItem  =  [UIBarButtonItem appearanceWhenContainedInInstancesOfClasses:@[[UISearchBar class]]];
            [cancleBarButtomItem setTitle:@"取消"];
            
        }else{
            
            // < 9
            cancleBarButtomItem =  [UIBarButtonItem appearanceWhenContainedIn:[UISearchBar class], nil];
            [cancleBarButtomItem setTitle:@"取消"];
            
        }
        
    }

    
}

+(instancetype)loadFromNib{
    
    return [[NSBundle mainBundle]loadNibNamed:NSStringFromClass(self.class) owner:nil options:nil][0];
}


///delegateMethod

/// 开始编辑
-(void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar{
    
    searchBar.showsCancelButton = YES;
    
}


/// 结束编辑
-(void)searchBarTextDidEndEditing:(UISearchBar *)searchBar{
    
    searchBar.showsCancelButton = NO;
}


/// 取消输入
-(void)searchBarCancelButtonClicked:(UISearchBar *)searchBar{
    
    searchBar.showsCancelButton = NO;
    [self endEditing:YES];
    
}


/// 检索
-(void)searchBarSearchButtonClicked:(UISearchBar *)searchBar{
    
    if ([self.delegate  respondsToSelector:@selector(search)]) {
        
        [self.delegate search];
    }
}



@end
